const express = require('express');
const app = express();

app.get('/', function(req, res) {
  connection.query("SELECT video_id FROM popular_music", function(err, rows, fields) {
    if (err) {
      throw err;
    } else {
      var videoIds = rows.map(function(row) {
        return row.video_id;
      });
      res.render('index', { videoIds: videoIds });
    }
  });
});

app.listen(3000, function() {
  console.log('Server is running on port 3000');
});
