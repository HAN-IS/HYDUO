const express = require('express');
var http = require('http');
var mysql = require('mysql');
var fs = require('fs');

const app = express();

var connection = mysql.createConnection({
    host          : "music.c7kawyrjby0j.ap-northeast-2.rds.amazonaws.com",
    user          : "admin",
    password      : "hyd12345",
    database      : "popidx"
})

var vids = [] ;

//connection.connect(function(err){
//    if(err){
//        throw err;
//    } else { 
//       connection.query("SELECT video_id FROM popular_music", function(err, rows, fields){
//           var videoIds = rows.map(function(row) {
//                return row.video_id;
//              });
//              //console.log(videoIds);
//           vids = videoIds;
//        })
//    }
//})
function getVideoIds() {
    return new Promise((resolve, reject) => {
      connection.query("SELECT video_id FROM popular_music", function(err, rows, fields) {
        if (err) {
          reject(err);
        } else {
          const videoIds = rows.map(function(row) {
            return row.video_id;
          });
          resolve(videoIds);
        }
      });
    });
  }
  async function initialize() {
    try {
      vids = await getVideoIds();
      console.log(vids);
    } catch (err) {
      console.error(err);
    }
  }
  connection.connect(function(err) {
    if (err) {
      throw err;
    } else {
      initialize();
    }
  });


var testserver = http.createServer(function (request, response) {
    var url = request.url;
    var videoIds = vids;
    var plistcode = "'" + videoIds.slice(0, 9).join(",") + "'"; // videoIds 배열에서 0부터 9까지의 값을 취함
    var template = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HY-DUO</title>
    </head>
    <body>
            <DIV class="video-background" id="media-1">
            <DIV class="video-foreground">
            <DIV id="player1" allowfullscreen="" frameborder="0"></DIV></DIV></DIV>
            <div id = "box"></div>
          <script>
            
    
    
            var tag = document.createElement('script');
    
            tag.src = "https://www.youtube.com/iframe_api";
            var firstScriptTag = document.getElementsByTagName('script')[0];
            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

            var player1;
            var plist = ['7HDeem-JaSY','WdiSosDz4ss','WdiSosDz4ss','XZaBkbvteBc','P2WN35hWy4A','O5qOB4cDr7s'];
            var plistcode = ${JSON.stringify(plistcode)};
    
            function onYouTubeIframeAPIReady() {
                player1 = new YT.Player('player1', {
                    videoId: 'xUV9pcwhY0U',
                    playerVars: {
                        'autoplay': 1,
                        'loop': 1,
                        'showinfo': 1,
                        'controls': 1,
                        'rel': 0,
                        'playlist': plistcode 
                    },
                    events: {
                        'onReady': onPlayerReady1,
                        'onStateChange': onPlayerStateChange, // 동영상 종료
                        'onError': onPlayerError // 동영상 에러 발생
                    }
                })
            }
    
            function onPlayerReady1(event) {
                event.target.playVideo();
                player1.setVolume(30);
            }
            
            function onPlayerError(event) {
            
            // 유튜브 동영상 퍼가기 금지 해놨을 경우 반환되는 에러
            
            if ( event.data == 150 )
            
            { }
            
            }
            function onPlayerStateChange(event) {
            
            // 현재 동영상 재생 종료됬을 경우
            
                    if (event.data == YT.PlayerState.ENDED) {
                    
            // 5초뒤에 다음 영상 실행
                    
                        setTimeout(onPlayerStateChange_excute, 5000); 
                    
                        }
                    
            }
          </script>
    </body>
    </html>
    
    `
    response.writeHead(200);
    response.end(template);
});
testserver.listen(3000);
console.log(vids);